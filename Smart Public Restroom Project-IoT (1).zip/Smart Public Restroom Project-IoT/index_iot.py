import paho.mqtt.client as mqtt
import RPi.GPIO as GPIO
import Adafruit_CharLCD as LCD
import time

# Configure GPIO pins for actuators and display
GPIO.setmode(GPIO.BCM)
FLUSH_PIN = 17  # Pin for flushing
CLEANING_PIN = 18  # Pin for cleaning (e.g., UV lights or cleaning robot)
DIGITAL_DISPLAY_PIN = 19  # Pin for the digital display
GPIO.setup(FLUSH_PIN, GPIO.OUT)
GPIO.setup(CLEANING_PIN, GPIO.OUT)
GPIO.setup(DIGITAL_DISPLAY_PIN, GPIO.OUT)

# Set up MQTT client for IoT communication
MQTT_BROKER = "your_broker_address"
MQTT_TOPIC_SENSORS = "restroom/sensors"
MQTT_CLIENT_ID = "restroom_pi"
client = mqtt.Client(MQTT_CLIENT_ID)
client.connect(MQTT_BROKER, 1883)

# Sensor reading functions (replace with actual sensor code)
def read_temperature_sensor():
    # Replace with code to read temperature sensor
    # Example: temperature = read_actual_temperature_sensor()
    temperature = 25.5  # Replace with actual sensor reading
    return temperature

def read_humidity_sensor():
    # Replace with code to read humidity sensor
    # Example: humidity = read_actual_humidity_sensor()
    humidity = 50.5  # Replace with actual sensor reading
    return humidity

def read_occupancy_sensor():
    # Replace with code to read occupancy sensor
    # Example: occupancy = read_actual_occupancy_sensor()
    occupancy = True  # Replace with actual sensor reading (True for occupied, False for vacant)
    return occupancy

# Flushing function
def flush_toilet():
    GPIO.output(FLUSH_PIN, GPIO.HIGH)  # Activate the flush mechanism
    time.sleep(2)  # Adjust as needed
    GPIO.output(FLUSH_PIN, GPIO.LOW)  # Deactivate the flush mechanism

# Cleaning function (example for periodic cleaning)
def clean_restroom():
    # Start the cleaning mechanism here
    print("Restroom is being cleaned.")
    GPIO.output(CLEANING_PIN, GPIO.HIGH)  # Activate cleaning mechanism
    time.sleep(5)  # Adjust as needed
    GPIO.output(CLEANING_PIN, GPIO.LOW)  # Deactivate cleaning mechanism

# Digital display function
def display_message(message):
    # Control the digital display to show the message
    print("Display message:", message)
    

# Initialize the LCD display
lcd = LCD.Adafruit_CharLCDPlate()

# Function to update the digital display with a message
def update_display(occupancy, temperature, humidity):
    lcd.clear()  # Clear the display

    # Display occupancy status
    if occupancy:
        lcd.message("Status: Occupied\n")
    else:
        lcd.message("Status: Vacant\n")

    # Display temperature and humidity
    lcd.message(f"Temp: {temperature}C\n")
    lcd.message(f"Humidity: {humidity}%")

# Example usage
if __name__ == "__main__":
    # Replace these with actual sensor readings
    occupancy = True  # Example occupancy status
    temperature = 25.5  # Example temperature reading
    humidity = 55.0  # Example humidity reading

    update_display(occupancy, temperature, humidity)

    # Keep the display on for a few seconds (adjust as needed)
    time.sleep(5)

    # Clear the display
    lcd.clear()

# MQTT message handler
def on_message(client, userdata, msg):
    # Process incoming MQTT messages
    payload = msg.payload.decode("utf-8")
# MQTT message handler
def on_message(client, userdata, msg):
    # Process incoming MQTT messages
    payload = msg.payload.decode("utf-8")

    # Define a list of valid commands you want to handle
    valid_commands = ["flush", "clean", "other_command"]

    if payload in valid_commands:
        if payload == "flush":
            # Implement logic to trigger a manual flushing
            manual_flushing()
        elif payload == "clean":
            # Implement logic to manually start a cleaning cycle
            manual_cleaning()
        # Add more elif conditions for other commands as needed

def manual_flushing():
    # Implement logic to manually trigger flushing
    # For example, you can activate the flush mechanism for a certain duration
    GPIO.output(FLUSH_PIN, GPIO.HIGH)
    time.sleep(2)  # Adjust the duration as needed
    GPIO.output(FLUSH_PIN, GPIO.LOW)

def manual_cleaning():
    # Implement logic to manually initiate cleaning
    # This might involve starting the cleaning mechanism
    print("Manual cleaning has been initiated.")
    GPIO.output(CLEANING_PIN, GPIO.HIGH)
    time.sleep(5)  # Adjust the duration as needed
    GPIO.output(CLEANING_PIN, GPIO.LOW)

# Subscribe to MQTT commands
client.subscribe("restroom/commands")
client.on_message = on_message
client.loop_start()
# Subscribe to MQTT commands
client.subscribe("restroom/commands")
client.on_message = on_message
client.loop_start()

# Counters for occupancy and cleaning
occupancy_counter = 0
cleaning_interval = 3  # Clean automatically every 3 persons

try:
    while True:
        temperature = read_temperature_sensor()
        humidity = read_humidity_sensor()
        occupancy = read_occupancy_sensor()

        # Detect person based on temperature rise
        if temperature > 25:
            occupancy_counter += 1

            # Check if it's time to trigger automatic cleaning
            if occupancy_counter >= cleaning_interval:
                clean_restroom()
                occupancy_counter = 0

        # Flushing logic based on humidity
        if humidity > 60:
            flush_toilet()

        # Publish sensor data to MQTT topic
        sensor_data = {
            "temperature": temperature,
            "humidity": humidity,
            "occupancy": occupancy
        }
        client.publish(MQTT_TOPIC_SENSORS, str(sensor_data))

        # Display sensor data on the digital display
        display_message(f"Temp: {temperature}°C, Humidity: {humidity}%, Occupancy: {occupancy}")

        time.sleep(10)  # Adjust the interval as needed

except KeyboardInterrupt:
    GPIO.cleanup()
    client.disconnect()
    client.loop_stop()
